#!/usr/bin/python

import simple_test

simple_test.test("test8", ["-s=bill", "-i=9", "-i=8", "-B", "homer", "marge", "bart", ])
