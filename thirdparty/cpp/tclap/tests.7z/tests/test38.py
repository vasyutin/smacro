#!/usr/bin/python

import simple_test

simple_test.test("test7", ["-n", "mike", "2", "1", ], expect_fail=True)
