#!/usr/bin/python

import simple_test

simple_test.test("test23", ["blah", "--blah", "-s=bill", "-i=9", "-i=8", "-B", "homer", "marge", "bart", ])
