#!/usr/bin/python

import simple_test

simple_test.test("test22", ["asdf", "-n", "mike", "asdf", "fds", "xxx", ])
