#!/usr/bin/python

import simple_test

simple_test.test("test19", ["-i", "012", ])
