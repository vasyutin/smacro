#!/usr/bin/python

import simple_test

simple_test.test("test5", ["-b", "asdf", "-c", "fdas", "-g", "asdf", "-j", "homer", ])
