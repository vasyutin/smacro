#!/usr/bin/python

import simple_test

simple_test.test("test11", ["-v", "1 2 3", ])
